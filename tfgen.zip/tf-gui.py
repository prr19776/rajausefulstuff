import streamlit as st
import json

# Assume this function integrates your Terraform code generation logic
from terraform_generator_util import generate_terraform_files_for_resource

# Load schema.json and extract resource names
def load_resource_names(schema_file='schema.json'):
    with open(schema_file) as f:
        schema = json.load(f)
    provider_name = next(iter(schema['provider_schemas']))  # Assumes single provider
    resources = schema['provider_schemas'][provider_name]['resource_schemas'].keys()
    return list(resources) , schema

def app():
    # Load resource names from the schema
    resource_names,schema = load_resource_names()

    # Create a dropdown to select a resource name
    # resource_name = st.selectbox('Select a Resource', resource_names,index=None,placeholder="Select contact method...")
    resource_types = st.multiselect('Select a Resource', resource_names)

    all_main_tf_content = ""
    all_variables_tf_content = ""

    for resource_type in resource_types:
        main_tf, variables_tf = generate_terraform_files_for_resource(resource_type, schema)
        all_main_tf_content += main_tf + "\n"
        all_variables_tf_content += "###"+resource_type+"###\n"+ variables_tf + "\n" 

    #     # # Display the generated Terraform blocks
    st.text_area("Main Block", all_main_tf_content, height=300)
    st.text_area("Variables Block", all_variables_tf_content, height=300)

if __name__ == "__main__":
    app()
