// import express from 'express';

const express = require('express');
const app = express();
const port = process.env.PORT || 3000;

app.get('/about', (req, res) => {
  res.status(200).json({ message: 'This is the /about endpoint', timestamp: new Date() });
});

app.get('/health', (req, res) => {
  res.status(200).json({ message: 'Healthy', timestamp: new Date() });
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
