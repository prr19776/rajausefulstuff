import re
import os

def remove_duplicate_variables(terraform_file_path):
    with open(terraform_file_path, 'r') as file:
        content = file.read()

    variable_block_pattern = re.compile(r'(variable\s+"[^"]+"\s+\{[\s\S]+?\})')
    variable_name_pattern = re.compile(r'variable\s+"([^"]+)"')

    variables_found = {}
    cleaned_content = ""

    for block in variable_block_pattern.findall(content):
        match = variable_name_pattern.search(block)
        if match:
            variable_name = match.group(1)
            if variable_name not in variables_found:
                variables_found[variable_name] = True
                cleaned_content += block + "\n\n"

    cleaned_file_path = terraform_file_path.replace('.tf', '_cleaned.tf')
    
    with open(cleaned_file_path, 'w') as file:
        file.write(cleaned_content)

    # Remove the original file
    os.remove(terraform_file_path)

    # Rename the cleaned file to the original file name
    os.rename(cleaned_file_path, terraform_file_path)

    print(f"Duplicate variables removed. The cleaned Terraform file is named {terraform_file_path}")

# Example usage
terraform_file_path = 'variables.tf'
remove_duplicate_variables(terraform_file_path)
