import re
import os

def remove_duplicate_variables_preserving_comments(terraform_file_path):
    variable_start_pattern = re.compile(r'^variable\s+"([^"]+)"\s+\{$')
    comment_pattern = re.compile(r'^\s*(#|//)')

    variables_found = set()
    cleaned_lines = []
    skip_block = False

    with open(terraform_file_path, 'r') as file:
        for line in file:
            # Check if the line is a comment
            if comment_pattern.match(line):
                cleaned_lines.append(line)
                continue

            # Check for the start of a variable block
            start_match = variable_start_pattern.match(line)
            if start_match:
                variable_name = start_match.group(1)
                if variable_name in variables_found:
                    skip_block = True  # Start skipping lines until the end of this block
                    continue
                else:
                    variables_found.add(variable_name)

            # If not skipping, add the line to the output
            if not skip_block:
                cleaned_lines.append(line)

            # If the current block ends, stop skipping
            if skip_block and line.strip() == '}':
                skip_block = False

    cleaned_file_path = terraform_file_path.replace('.tf', '_cleaned.tf')
    
    # Write the processed lines to a new file
    with open(cleaned_file_path, 'w') as file:
        file.writelines(cleaned_lines)

    # Optionally replace the original file with the cleaned file
    os.remove(terraform_file_path)  # Be careful with this line, consider backing up the original file
    os.rename(cleaned_file_path, terraform_file_path)

    print(f"Duplicate variables removed, preserving comments. The cleaned Terraform file is named {terraform_file_path}")

# Example usage
terraform_file_path = 'variables.tf'
remove_duplicate_variables_preserving_comments(terraform_file_path)

