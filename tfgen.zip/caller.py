from terraform_generator_util import generate_terraform_files_for_resource
import json

def generate_terraform_files(resource_types, schema_file='schema.json'):
    all_main_tf_content = ""
    all_variables_tf_content = ""

    with open(schema_file) as f:
        schema = json.load(f)

    for resource_type in resource_types:
        main_tf, variables_tf = generate_terraform_files_for_resource(resource_type, schema)
        all_main_tf_content += main_tf + "\n"
        all_variables_tf_content += "###"+resource_type+"###\n"+ variables_tf + "\n"

    # Write aggregated content to single files
    with open("main.tf", "w") as f_main:
        f_main.write(all_main_tf_content)
    with open("variables.tf", "w") as f_vars:
        f_vars.write(all_variables_tf_content)

    print("Generated main.tf and variables.tf with all specified resources.")

resource_types = ["azurerm_mssql_server","azurerm_mssql_elasticpool"]  # Extend this list as needed
generate_terraform_files(resource_types)
