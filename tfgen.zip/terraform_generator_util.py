import json

def parse_attribute_type(attr_type):
    if "string" in attr_type:
        return "string", '""'
    elif "bool" in attr_type:
        return "bool", "false"
    elif "int" in attr_type or "float" in attr_type or "number" in attr_type:
        return "number", "0"
    elif "list" in attr_type or "set" in attr_type:
        return "list(any)", "[]"
    elif "map" in attr_type:
        return "map(any)", "{}"
    else:
        return "any", ""

def default_value_comment(default):
    if isinstance(default, str) and default != "":
        return f" Default: {default}"
    return ""

def generate_complex_block_structure(block_name, block_details):
    return f"# {block_name} is a complex block, manual configuration required\n"

def generate_terraform_files_for_resource(resource_type, schema):
    main_tf = f'resource "{resource_type}" "example" {{\n'
    variables_tf = ""

    # Example correction based on expected structure
    provider_name = "registry.terraform.io/hashicorp/azurerm"
    resource_schema = schema['provider_schemas'][provider_name]['resource_schemas'][resource_type]

    # print(resource_schema)

    for attr, details in resource_schema['block']['attributes'].items():
        attr_type, attr_default = parse_attribute_type(details['type'])
        optional = "optional" in details and details['optional']
        default_comment = default_value_comment(attr_default)

        optionality_comment = f"Optional - {attr_type}" if optional else f"Required - {attr_type}"
        main_tf += f'  {attr} = var.{attr}  # {optionality_comment}\n'

        default_attr = f'  default = {attr_default}' if optional and attr_default != "" else ""
        
        variables_tf += f'''variable "{attr}" {{
        type        = {attr_type}
        description = "{optionality_comment}"''' + (f'\n  {default_attr}' if default_attr else '') + '\n}\n\n'

    if 'block_types' in resource_schema['block']:
        for block_name, block_details in resource_schema['block']['block_types'].items():
            block_structure = generate_complex_block_structure(block_name, block_details)
            main_tf += block_structure
            variables_tf += f'''variable "{block_name}" {{
  type        = any
  description = "Complex type - manual configuration required"
}}\n\n'''

    main_tf += "}\n"
    return main_tf, variables_tf
